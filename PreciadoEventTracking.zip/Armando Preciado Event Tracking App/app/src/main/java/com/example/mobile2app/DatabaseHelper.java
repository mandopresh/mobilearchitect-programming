package com.example.mobile2app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UserData.db";
    private static final int DATABASE_VERSION = 2; // Increment version if modifying schema

    private static final String TABLE_EVENTS = "events";
    private static final String TABLE_USERS = "users";

    // Columns for Events table
    private static final String EVENT_ID = "ID";
    private static final String EVENT_TITLE = "TITLE";
    private static final String EVENT_DATE = "DATE";
    private static final String EVENT_LOCATION = "LOCATION";
    private static final String EVENT_DESCRIPTION = "DESCRIPTION";

    // Columns for Users table
    private static final String USER_ID = "ID";
    private static final String USERNAME = "USERNAME";
    private static final String PASSWORD = "PASSWORD";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE, " +
                PASSWORD + " TEXT)";
        db.execSQL(createUserTable);

        // Create Events table
        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EVENT_TITLE + " TEXT, " +
                EVENT_DATE + " TEXT, " +
                EVENT_LOCATION + " TEXT, " +
                EVENT_DESCRIPTION + " TEXT)";
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // Insert new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Check if user exists
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + USERNAME + " = ? AND " + PASSWORD + " = ?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Insert new event
    public boolean insertEvent(String title, String date, String location, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EVENT_TITLE, title);
        values.put(EVENT_DATE, date);
        values.put(EVENT_LOCATION, location);
        values.put(EVENT_DESCRIPTION, description);

        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();
        return result != -1;
    }

    // Retrieve all events
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " ORDER BY " + EVENT_DATE + " ASC", null);
    }

    // Update an event
    public boolean updateEvent(String id, String title, String date, String location, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EVENT_TITLE, title);
        values.put(EVENT_DATE, date);
        values.put(EVENT_LOCATION, location);
        values.put(EVENT_DESCRIPTION, description);

        int result = db.update(TABLE_EVENTS, values, "ID=?", new String[]{id});
        db.close();
        return result > 0;
    }

    // Delete an event
    public int deleteEvent(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_EVENTS, "ID=?", new String[]{id});
        db.close();
        return rowsDeleted;
    }
}


