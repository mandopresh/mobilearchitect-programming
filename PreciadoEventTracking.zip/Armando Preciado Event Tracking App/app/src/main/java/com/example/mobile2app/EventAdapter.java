package com.example.mobile2app;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {
    private Context context;
    private List<Event> eventList;
    private DatabaseHelper databaseHelper;

    public EventAdapter(Context context, List<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
        this.databaseHelper = new DatabaseHelper(context);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, date, location, description;
        Button buttonEdit, buttonDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.eventTitle);
            date = itemView.findViewById(R.id.eventDate);
            location = itemView.findViewById(R.id.eventLocation);
            description = itemView.findViewById(R.id.eventDescription);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.title.setText(event.getTitle());
        holder.date.setText("Date: " + event.getDate());
        holder.location.setText("Location: " + event.getLocation());
        holder.description.setText("Description: " + event.getDescription());

        // 🗑 DELETE event
        holder.buttonDelete.setOnClickListener(v -> {
            databaseHelper.deleteEvent(String.valueOf(event.getId())); // Remove from DB
            eventList.remove(position); // Remove from list
            notifyItemRemoved(position); // Update RecyclerView
            Toast.makeText(context, "Event Deleted", Toast.LENGTH_SHORT).show();
        });

        // ✏ EDIT event
        holder.buttonEdit.setOnClickListener(v -> showEditDialog(event, position));
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    // 📝 Show Edit Dialog
    private void showEditDialog(Event event, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context); // ✅ Use context properly
        builder.setTitle("Edit Event");

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_event, null);
        EditText editTitle = view.findViewById(R.id.editTextEditTitle);
        EditText editDate = view.findViewById(R.id.editTextEditDate);
        EditText editLocation = view.findViewById(R.id.editTextEditLocation);
        EditText editDescription = view.findViewById(R.id.editTextEditDescription);

        // Set current values
        editTitle.setText(event.getTitle());
        editDate.setText(event.getDate());
        editLocation.setText(event.getLocation());
        editDescription.setText(event.getDescription());

        builder.setView(view);
        builder.setPositiveButton("Update", (dialog, which) -> {
            String newTitle = editTitle.getText().toString().trim();
            String newDate = editDate.getText().toString().trim();
            String newLocation = editLocation.getText().toString().trim();
            String newDescription = editDescription.getText().toString().trim();

            if (!newTitle.isEmpty() && !newDate.isEmpty() && !newLocation.isEmpty() && !newDescription.isEmpty()) {
                databaseHelper.updateEvent(String.valueOf(event.getId()), newTitle, newDate, newLocation, newDescription);
                event.setTitle(newTitle);
                event.setDate(newDate);
                event.setLocation(newLocation);
                event.setDescription(newDescription);
                notifyItemChanged(position);
                Toast.makeText(context, "Event Updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Fields Cannot Be Empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}

