package com.example.mobile2app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    DatabaseHelper databaseHelper;
    EditText editTextTitle, editTextDate, editTextLocation, editTextDescription;
    Button buttonAdd, buttonBackHome;
    RecyclerView recyclerView;
    EventAdapter eventAdapter;
    List<Event> eventList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        databaseHelper = new DatabaseHelper(this);

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextDate = findViewById(R.id.editTextDate);
        editTextLocation = findViewById(R.id.editTextLocation);
        editTextDescription = findViewById(R.id.editTextDescription);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonBackHome = findViewById(R.id.buttonBackHome);
        recyclerView = findViewById(R.id.recyclerView);

        // Setup RecyclerView
        eventList = new ArrayList<>();
        eventAdapter = new EventAdapter(this, eventList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(eventAdapter);

        // ✅ Request SMS Permission at startup
        requestSmsPermission();

        buttonAdd.setOnClickListener(v -> {
            String title = editTextTitle.getText().toString();
            String date = editTextDate.getText().toString();
            String location = editTextLocation.getText().toString();
            String description = editTextDescription.getText().toString();

            if (!title.isEmpty() && !date.isEmpty() && !location.isEmpty() && !description.isEmpty()) {
                boolean inserted = databaseHelper.insertEvent(title, date, location, description);
                if (inserted) {
                    Toast.makeText(DataActivity.this, "Event Added", Toast.LENGTH_SHORT).show();
                    clearFields();
                    displayData();

                    // ✅ Check if SMS permission is granted before sending SMS
                    if (ContextCompat.checkSelfPermission(DataActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendSmsNotification("+1234567890", "Reminder: Upcoming Event - " + title + " on " + date + " at " + location);
                    } else {
                        Toast.makeText(DataActivity.this, "SMS permission not granted. Cannot send notification.", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(DataActivity.this, "Error Adding Event", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DataActivity.this, "Fields Cannot Be Empty", Toast.LENGTH_SHORT).show();
            }
        });

        buttonBackHome.setOnClickListener(v -> {
            Intent intent = new Intent(DataActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });

        displayData();
    }

    private void displayData() {
        eventList.clear();
        Cursor cursor = databaseHelper.getAllEvents();

        while (cursor.moveToNext()) {
            eventList.add(new Event(
                    cursor.getInt(cursor.getColumnIndexOrThrow("ID")),
                    cursor.getString(cursor.getColumnIndexOrThrow("TITLE")),
                    cursor.getString(cursor.getColumnIndexOrThrow("DATE")),
                    cursor.getString(cursor.getColumnIndexOrThrow("LOCATION")),
                    cursor.getString(cursor.getColumnIndexOrThrow("DESCRIPTION"))
            ));
        }

        eventAdapter.notifyDataSetChanged();
        cursor.close();
    }

    private void clearFields() {
        editTextTitle.setText("");
        editTextDate.setText("");
        editTextLocation.setText("");
        editTextDescription.setText("");
    }

    // ✅ Request SMS Permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // ✅ Handle User's Response (Allow/Deny)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. SMS Notifications will not work.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ✅ Send SMS Notification
    private void sendSmsNotification(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}


