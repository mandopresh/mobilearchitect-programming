package com.example.mobile2app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    Button buttonGrantPermission, buttonDenyPermission;
    TextView textPermissionMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        buttonGrantPermission = findViewById(R.id.buttonGrantPermission);
        buttonDenyPermission = findViewById(R.id.buttonDenyPermission);
        textPermissionMessage = findViewById(R.id.textPermissionMessage);

        // Handle "Grant Permission" Button
        buttonGrantPermission.setOnClickListener(v -> requestSmsPermission());

        // Handle "Deny Permission" Button
        buttonDenyPermission.setOnClickListener(v -> {
            Toast.makeText(this, "SMS Permission Denied. App will function without SMS notifications.", Toast.LENGTH_LONG).show();
            navigateToMainApp();
        });
    }

    // ✅ Request SMS Permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            navigateToMainApp();
        }
    }

    // Handle User Response (Allow/Deny)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. App will function without SMS notifications.", Toast.LENGTH_LONG).show();
            }
            navigateToMainApp();
        }
    }

    // Navigate to the main app (DataActivity)
    private void navigateToMainApp() {
        Intent intent = new Intent(SMSActivity.this, DataActivity.class);
        startActivity(intent);
        finish();
    }
}
