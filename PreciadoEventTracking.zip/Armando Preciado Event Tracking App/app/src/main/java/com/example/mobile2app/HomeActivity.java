package com.example.mobile2app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    Button buttonToData, buttonLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        buttonToData = findViewById(R.id.buttonToData);
        buttonLogout = findViewById(R.id.buttonLogout);

        // Navigate to Data Activity
        buttonToData.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, DataActivity.class);
            startActivity(intent);
        });

        // Logout (Return to Login Screen)
        buttonLogout.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Closes HomeActivity to prevent going back
        });
    }
}

